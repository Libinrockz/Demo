from django.shortcuts import render,HttpResponse,get_object_or_404
from .models import flight_details
from .forms import MyLoginForm,FlightForm,FlightSearchForm
from django.contrib.auth import authenticate,login
from django.contrib import messages
from django.contrib.auth import logout



# Create your views here.
def main(request):

   return render(request,template_name='airline.html')

def flightdetails(request):
   flight_list = flight_details.objects.all()
   print(flight_list)
   return render(request, template_name='flight_details.html', context={'flight_list': flight_list})


def user_login(request):
   if request.method == 'POST':
      login_form = MyLoginForm(request.POST)
      if login_form.is_valid():
         cleaned_data = login_form.cleaned_data
         auth_user = authenticate(request, username=cleaned_data['username'], password=cleaned_data['password'])

         if auth_user is not None:
            # Check if the user is admin
            if auth_user.is_superuser:  # Ensuring only admin can log in
               login(request, auth_user)
               return redirect('main')  # Redirect to the main admin page
            else:
               messages.error(request, 'Only admin can log in.')  # Message for non-admin users
         else:
            messages.error(request, 'Invalid username or password.')
   else:
      login_form = MyLoginForm()

   return render(request, 'useraccount/login_form.html', {'login_form': login_form})
from django.shortcuts import render, redirect


def user_logout_view(request):
   logout(request)
   return redirect('login')


def view_flight(request, flight_id):
    flightdetails = get_object_or_404(flight_details, flight_id=flight_id)  # Fetch the flight by flight_id
    return render(request, 'view_flight.html', {'flightdetails': flightdetails})  # Pass as 'flightdetails'


def add_edit_delete(request):
   flight_list = flight_details.objects.all()
   form = FlightForm()
   return render(request, 'add_edit_delete.html', {'flight_list': flight_list, 'form': form})


# Add flight view
def add_flight(request):
   if request.method == 'POST':
      form = FlightForm(request.POST)
      if form.is_valid():
         form.save()
         messages.success(request, 'Flight added successfully.')
         return redirect('add_edit_delete')  # Redirect back to home page with flight list
   else:
      form = FlightForm()
   return render(request, 'add_flight.html', {'form': form})


# Edit flight view
def edit_flight(request, flight_id):
   flight = get_object_or_404(flight_details, flight_id=flight_id)
   if request.method == 'POST':
      form = FlightForm(request.POST, instance=flight)
      if form.is_valid():
         form.save()
         messages.success(request, 'Flight details updated successfully.')
         return redirect('add_edit_delete')
   else:
      form = FlightForm(instance=flight)
   return render(request, 'edit_flight.html', {'form': form, 'flight': flight})


# Delete flight view
def delete_flight(request, flight_id):
   flight = get_object_or_404(flight_details, flight_id=flight_id)
   if request.method == 'POST':
      flight.delete()
      messages.success(request, 'Flight deleted successfully.')
      return redirect('add_edit_delete')
   return render(request, 'delete_flight.html', {'flight': flight})


def search_flight(request):
   flight = None
   search_form = FlightSearchForm()

   if request.method == 'POST':
      search_form = FlightSearchForm(request.POST)
      if search_form.is_valid():
         flight_id = search_form.cleaned_data.get('flight_id')
         try:
            # Try to find the flight by flight_id
            flight = flight_details.objects.get(flight_id=flight_id)
         except flight_details.DoesNotExist:
            flight = None  # Flight not found

   return render(request, 'search_flight.html', {'search_form': search_form, 'flight': flight})