from django import forms
from .models import User,flight_details


class MyLoginForm(forms.Form):
   username = forms.CharField()
   password = forms.CharField(widget=forms.PasswordInput)


class FlightForm(forms.ModelForm):
   class Meta:
      model = flight_details
      fields = ['flight_id', 'departure_airport', 'departure_airport_date', 'departure_airport_time',
                'arrival_airport', 'arrival_airport_date', 'arrival_airport_time']
      widgets = {
         'departure_airport_date': forms.DateInput(attrs={'class': 'form-control', 'type': 'date'}),
         'departure_airport_time': forms.TimeInput(attrs={'class': 'form-control', 'type': 'time'}),
         'arrival_airport_date': forms.DateInput(attrs={'class': 'form-control', 'type': 'date'}),
         'arrival_airport_time': forms.TimeInput(attrs={'class': 'form-control', 'type': 'time'}),
      }


class FlightSearchForm(forms.Form):
   flight_id = forms.CharField(max_length=500, label='Flight ID')