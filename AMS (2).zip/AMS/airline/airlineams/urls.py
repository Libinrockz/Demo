"""
URL configuration for airline project.

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/4.2/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path

from django.urls import path
from .views import main,user_login,user_logout_view,flightdetails,view_flight,add_edit_delete,add_flight,edit_flight,delete_flight,search_flight

urlpatterns = [
   path('', user_login, name='login'),
   path('logout/', user_logout_view, name='logout'),
   path('airline', main, name='main'),
   path('flight_details', flightdetails, name='flightdetails'),
   path('view_flight/<str:flight_id>/', view_flight, name='view_flight'),
   path('add_edit_delete', add_edit_delete, name='add_edit_delete'),
   path('add_flight/', add_flight, name='add_flight'),
   path('edit_flight/<str:flight_id>/', edit_flight, name='edit_flight'),
   path('delete_flight/<str:flight_id>/', delete_flight, name='delete_flight'),
   path('search-flight/', search_flight, name='search_flight'),
]

