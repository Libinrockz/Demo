from django.db import models
from django.contrib.auth.models import User

# Create your models here.

class flight_details(models.Model):
    flight_id = models.CharField(max_length=500)
    departure_airport = models.CharField(max_length=500)
    departure_airport_date = models.DateField(null=True, blank=True)
    departure_airport_time = models.TimeField(null=True, blank=True)
    arrival_airport = models.CharField(max_length=500)
    arrival_airport_date = models.DateField(null=True, blank=True)
    arrival_airport_time = models.TimeField(null=True, blank=True)

    def __str__(self):
       return self.flight_id